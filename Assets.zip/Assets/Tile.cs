using UnityEngine;
using System.Collections.Generic;

public class Tile : MonoBehaviour
{
    public int x;
    public int y;
    public List<Tile> neighbors;
    public Piece OccupiedBy()
    {
        foreach(Piece p in Manager.instance.pieces)if(p.x == x && p.y ==y)return p;
        return null;
    }
}
