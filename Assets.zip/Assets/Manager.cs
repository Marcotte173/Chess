using UnityEngine;
using System.Collections.Generic;
public enum PieceType {Pawn,Bishop,Knight,Rook,Queen,King}
public class Manager : MonoBehaviour
{
    public static Manager instance;
    public Tile tileTemplate;
    public Piece pieceTemplate;
    public List<Sprite> player1Pieces;
    public List<Sprite> player2Pieces;
    public List<GameObject> pieceObject;
    public List<Piece> pieces;
    public List<Tile> tiles;
    public List<Color> colors;
    public int turn;
    public Tile selected;
    public Tile mouseTile;
    public void Start()
    {
        instance = this;
        CreateBoard();
        SetUpPieces(0,1,1);
        SetUpPieces(7,6,2);
        turn = 1;
    }

    public void CreateBoard()
    {
        for(int j = 0; j<8;j++)
        {
            for(int i = 0; i<8;i++)
            {
                Tile tile = Instantiate(tileTemplate,transform);
                tile.transform.position = new Vector3(i,j,0);
                tile.x = i;
                tile.y = j;
                tile.name = $"{i} , {j}";
                
                tiles.Add(tile);
            }
        }
        foreach(Tile t in tiles)
        {
            foreach(Tile tile in tiles)
            {
                if(tile.x ==t.x +1 && tile.y  == t.y+1)t.neighbors.Add(tile);
                if(tile.x ==t.x +1 && tile.y  == t.y-1)t.neighbors.Add(tile);
                if(tile.x ==t.x +1 && tile.y  == t.y)t.neighbors.Add(tile);
                if(tile.x ==t.x -1 && tile.y  == t.y+1)t.neighbors.Add(tile);
                if(tile.x ==t.x -1 && tile.y  == t.y-1)t.neighbors.Add(tile);
                if(tile.x ==t.x -1 && tile.y  == t.y)t.neighbors.Add(tile);
                if(tile.x ==t.x  && tile.y  == t.y+1)t.neighbors.Add(tile);
                if(tile.x ==t.x  && tile.y  == t.y-1)t.neighbors.Add(tile);
            }
        }
    }
    public void SetUpPieces(int row1,int row2, int player)
    {
        CreatePiece(0,row1,player,PieceType.Rook);   
        CreatePiece(1,row1,player,PieceType.Knight);    
        CreatePiece(2,row1,player,PieceType.Bishop);   
        CreatePiece(3,row1,player,PieceType.Queen);               
        CreatePiece(4,row1,player,PieceType.King);   
        CreatePiece(5,row1,player,PieceType.Bishop);   
        CreatePiece(6,row1,player,PieceType.Knight);     
        CreatePiece(7,row1,player,PieceType.Rook);    
        for(int i = 0; i<8;i++) CreatePiece(i,row2,player,PieceType.Pawn);        
    }
    public void CreatePiece(int x, int y, int player, PieceType type)
    {
        Piece p = Instantiate(pieceTemplate,pieceObject[player-1].transform);
        p.player = player;
        p.ChangePiece(type);
        p.Move(x,y);
        pieces.Add(p);
    }
    public void Update()
    {
        mouseTile = FindTile(Mathf.Round(Camera.main.ScreenToWorldPoint(Input.mousePosition).x), Mathf.Round(Camera.main.ScreenToWorldPoint(Input.mousePosition).y));
        if(Input.GetMouseButtonDown(0))
        {
            if(mouseTile!=null && mouseTile.OccupiedBy()!= null && mouseTile.OccupiedBy().player == turn)selected = mouseTile;
            else selected = null;
        }
        if(Input.GetMouseButtonDown(1))selected = null;
        ColorUpdate();
    }
    public void ColorUpdate()
    {
        foreach(Tile t in tiles)
        {
            if(selected == t)  t.GetComponent<SpriteRenderer>().color = colors[3];
            else if(mouseTile== t && selected == null) t.GetComponent<SpriteRenderer>().color = colors[2];
            else t.GetComponent<SpriteRenderer>().color = colors[(t.x+t.y)%2];
        }
    }

    public Tile FindTile(float x, float y)
    {
        foreach(Tile t in tiles)if(t.x == x && t.y == y) return t;
        return null;
    }

    //public Tile Tile9(Tile current)
    //{

    //}
}