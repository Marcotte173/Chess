using UnityEngine;

public class Piece : MonoBehaviour
{
    public string pieceName;
    public PieceType type;
    public int player;
    public int x;
    public int y;
    public void ChangePiece(PieceType t)
    {
        type = t;
        pieceName = name = $"{type} - Player {player}";
        GetComponent<SpriteRenderer>().sprite =player == 1? Manager.instance.player1Pieces[(int)type]:Manager.instance.player2Pieces[(int)type];
    }
    public void Move(int x, int y)
    {
        transform.position = new Vector3(x,y,0);
        this.x = x;
        this.y = y;
    }
    public Tile Occupying()
    {
        foreach(Tile p in Manager.instance.tiles)if(p.x == x && p.y ==y)return p;
        return null;
    }
}
